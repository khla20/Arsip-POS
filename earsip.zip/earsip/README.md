# RACODE Generator Beta by [belajarphp.net](http://belajarphp.net)#
racode generator adalah sebuah tools yang mempermudah developer dalam proses development,
tools ini dibangun atas 5 komponen utama yaitu : <br>
1. framework codeigniter 3<br>
2. harviacode crud generator versi 1.3.0<br>
3. ION auth library<br>
4. template AdminLTE<br>
5. menu management<br><br>

Informasi Selengkapnya 
https://belajarphp.net/racode-generator-tools-for-development-2/
<br>
# Tutorial Membuat Aplikasi Dengan Racode
Dalam waktu dekat saya akan merilis beberapa tutorial membuat aplikasi dengan racode, tutorial ini akan saya bagikan gratis pada halaman ini.

# Cara Install
1. Masuk ke phpmyadmin, buat database dengan nama demo<br>
2. Copy paste isi demo.sql ke dalam database demo<br>
3. Setting database password di application/config/database.php<br>
4. Setting base_uri di application/config/config.php<br><br>

# User Login
Jika anda mengalami masalah login, gunakan email dan password default
> admin@admin.com
>
> password

