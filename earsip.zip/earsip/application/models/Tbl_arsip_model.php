<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tbl_arsip_model extends CI_Model
{

    public $table = 'tbl_arsip';
    public $id = 'id_arsip';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }
    
    function get_all_query($jenis_surat){
        $sql ="SELECT a.*,d.nama_departemen,p.nama_pengirim 
                FROM tbl_arsip AS a,tbl_departemen as d,tbl_pengirim_surat as p 
                WHERE a.id_departemen=d.id_departemen and a.id_pengirim=p.id_pengirim
                and a.jenis_surat='$jenis_surat'";
        return $this->db->query($sql)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('id_arsip', $q);
	$this->db->or_like('no_surat', $q);
	$this->db->or_like('tanggal_surat', $q);
	$this->db->or_like('tanggal_diterima', $q);
	$this->db->or_like('perihal', $q);
	$this->db->or_like('id_departemen', $q);
	$this->db->or_like('id_pengirim', $q);
	$this->db->or_like('file', $q);
	$this->db->or_like('jenis_surat', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id_arsip', $q);
	$this->db->or_like('no_surat', $q);
	$this->db->or_like('tanggal_surat', $q);
	$this->db->or_like('tanggal_diterima', $q);
	$this->db->or_like('perihal', $q);
	$this->db->or_like('id_departemen', $q);
	$this->db->or_like('id_pengirim', $q);
	$this->db->or_like('file', $q);
	$this->db->or_like('jenis_surat', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}

